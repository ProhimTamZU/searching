# Invoice #001
- Amount: $500
- Due Date: 2024-09-27
- Client: Company XYZ
- Description: Web development services.
